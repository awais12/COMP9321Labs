import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;


public class SimpleGetter {
	
	
	public static void main(String args[]) throws UnknownHostException, IOException{
		
		/*create new instance of the URL */
		URL newURL = new URL(args[0]);
		/*assign the socket */
		Socket socket = new Socket(newURL.getHost(), 80);
		/*perform the GET method */
		OutputStream out = socket.getOutputStream();
		String msg = "GET " +newURL.getPath()+" HTTP/1.1" + "\r\n" + "Host: "
						+ newURL.getHost() + "\r\n\r\n";
		out.write(msg.getBytes());
		/*read the data from inputstream */
		InputStream in = socket.getInputStream();
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		String inputLine;
		while ((inputLine = br.readLine()) != null)
		    System.out.println(inputLine);
		br.close();
		
		
	}

}
