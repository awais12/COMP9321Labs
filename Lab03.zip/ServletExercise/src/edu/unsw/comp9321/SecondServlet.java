package edu.unsw.comp9321;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * SecondServlet - output of this servlet is included in first
 * 
 * Also demonstrates attributes and parameters.
 * 
 */
@WebServlet(urlPatterns="/second",displayName="SecondServlet")
public class SecondServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SecondServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html"); 
		PrintWriter out = response.getWriter(); 
		Enumeration e = request.getAttributeNames();
		Enumeration e2 = request.getParameterNames();
		/*
		 * Print the attributes including one provided by FirstServlet
		 */
		out.println("<B>Second: Request Attributes</B><BR>");
		out.println("<ul>");
		while (e.hasMoreElements()) {
			String attributeName = (String) e.nextElement(); 
			out.println("<li> "+attributeName + ": " + request.getAttribute(attributeName) + "</li>");
		}
		out.println("</ul>");
		
		/*
		 * Print the parameters provided via GET method from FirstServlet's
		 * RequestDispatcher
		 */
		out.println("<B>Second: Request Parameters</B><BR>");
		out.println("<ul>");
		while (e2.hasMoreElements()) {
			String paramName = (String) e2.nextElement(); 
			out.println("<li> "+paramName + ": " + request.getParameter(paramName) + "</li>");
		}
		out.println("</ul>");
		
		String greet = (String)request.getAttribute("Greeting");
		out.println("<p>Second: SecondServlet says "+greet+"</p>");
		request.removeAttribute("Greeting");
		out.println("<p>Second: Over to the FirstServlet</p>");
	}


}
