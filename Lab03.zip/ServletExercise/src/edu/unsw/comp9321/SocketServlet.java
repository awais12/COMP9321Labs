package edu.unsw.comp9321;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * SocketServlet - demos a scenario where a servlet opens a socket.
 */
@WebServlet(urlPatterns="/socketdemo",displayName="SocketDemo")
public class SocketServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SocketServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		URL url = new URL("http://cgi.cse.unsw.edu.au/~srikumarv/test.html");
		Socket socket = new Socket(url.getHost(), 80);
		ServerSocket ss = new ServerSocket();
		response.setContentType("text/html"); 
		PrintWriter out = response.getWriter();
		out.println("<HTML><HEAD>"); 
		out.println("<TITLE>ServletTwo</TITLE>");
		out.println("</HEAD><BODY>");
		out.println("<H1>The socket is bound to :"+socket.getLocalAddress()+" </H1>");
		out.println("<h2>Don't do this!</h2>");
		out.println("</BODY></HTML>");
		out.close();
	}


}
