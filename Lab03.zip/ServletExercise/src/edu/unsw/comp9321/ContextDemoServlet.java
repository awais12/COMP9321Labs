package edu.unsw.comp9321;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * ContextDemoServlet 
 */
@WebServlet(urlPatterns="/contextdemo",displayName="ContextDemo")
public class ContextDemoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ContextDemoServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ServletContext sc = getServletConfig().getServletContext(); 
		Enumeration attributes = sc.getAttributeNames(); 
		PrintWriter out = response.getWriter(); 
		out.println("<HTML><BODY><H1>Display context parameters</H1><UL>");
		while (attributes.hasMoreElements()) {
			String attribute = (String) attributes.nextElement(); 
			out.println("<li>Attr name : " + attribute+"</li>"); 
			out.println("<li>Attr value : " + sc.getAttribute(attribute)+"</li>");
		}
		out.println("<li>Major version: " + sc.getMajorVersion() +"</li>\n"); 
		out.println("<li>Minor version: " + sc.getMinorVersion() + "</li>\n"); 
		out.println("<li>Server Info: " + sc.getServerInfo() +"</li>\n"); 
		String currencyUsed = sc.getInitParameter("aim"); 
		out.println("<li>Context Param Aim: " + currencyUsed + "</li>");
		out.close(); 
		out.println("</UL></BODY></HTML>");
	}

}
