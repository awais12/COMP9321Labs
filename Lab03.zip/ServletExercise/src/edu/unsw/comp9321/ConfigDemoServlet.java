package edu.unsw.comp9321;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * ConfigDemoServlet displays the information contained in the init parameters
 * of a Servlet
 */
@WebServlet(urlPatterns="/configdemo",displayName="ConfigDemo", 
initParams={
		@WebInitParam(name="author",value="srikumar"),
		@WebInitParam(name="course",value="COMP9321"),
		@WebInitParam(name="week",value="1")
})
public class ConfigDemoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ConfigDemoServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter(); 
		out.println("<HTML><BODY><H1>Display init parameters</H1><UL>"); 
		Enumeration e = getServletConfig().getInitParameterNames();

		while(e.hasMoreElements()){
			String paraName = (String) e.nextElement(); 
			out.println("<LI>Param name: " + paraName); 
			out.println("<LI>Param value: " + getServletConfig().getInitParameter(paraName)); 
		}
		out.close(); 
		out.println("</UL></BODY></HTML>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
