package edu.unsw.comp9321;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * HeaderServlet displays the information contained in the Headers
 */
@WebServlet(urlPatterns="/headerdemo",displayName="HeaderDemo")
public class HeaderServlet extends HttpServlet {
	final Logger logger = Logger.getLogger(this.getClass().getName());
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HeaderServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		logger.info(getServletName()+" invoked");
		response.setContentType("text/html"); 
		PrintWriter out = response.getWriter();
		out.println("<HTML>"); 
		out.println("<HEAD>");
		out.println("<TITLE>Header Info</TITLE>"); 
	
		out.println("</HEAD>"); 
		out.println("<BODY>");
		Enumeration<String> headers = request.getHeaderNames();
		String header = "";
		while(headers.hasMoreElements()){
			header = headers.nextElement();
			out.println("<b> "+header+" : </b> "+request.getHeader(header)+"<br/>");
		}
		//out.println("<H1> Hello "+name + "</H1>"); 
		out.println("</BODY>"); 
		out.println("</HTML>");
		out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}

}
