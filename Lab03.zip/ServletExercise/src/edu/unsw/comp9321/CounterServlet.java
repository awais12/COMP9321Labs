package edu.unsw.comp9321;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * CounterServlet provides an example of a GET method that 
 * changes server state. This should be avoided. 
 */
@WebServlet(urlPatterns="/counterdemo",displayName="CounterDemo")
public class CounterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private int counter;
       
    public CounterServlet() {
        super();
        counter = 0;
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html"); 
		PrintWriter out = response.getWriter();
		counter += 1;
		out.println("<HTML><HEAD>"); 
		out.println("<TITLE>ServletTwo</TITLE>");
		out.println("</HEAD><BODY>");
		out.println("<H1>This page has been visited "+counter+" times</H1>");
		//out.println("<h1>My country is "+request.getAttribute("country")+"<h1>");
		//out.println("<B>Request Parameters in SecondServlet</B><BR>");
		out.println("<h2>Try Refresh to see change in coutner</h2>");
		out.println("<h2>Don't do this!</h2>");
		out.println("</BODY></HTML>");
		out.close();
	}


}
